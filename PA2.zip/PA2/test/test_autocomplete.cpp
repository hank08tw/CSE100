#include "../src/Autocomplete.hpp"

int main() {
  //TODO your tests here
}
