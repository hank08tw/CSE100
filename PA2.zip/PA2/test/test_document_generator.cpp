#include "../src/DocumentGenerator.hpp"

int main() {
  //TODO your tests here
}
