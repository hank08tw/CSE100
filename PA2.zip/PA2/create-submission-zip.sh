#!/usr/bin/env bash

zip -r ./submission.zip ./src/* Makefile

