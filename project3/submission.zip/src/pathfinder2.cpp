
#include "ActorGraph.hpp"

#include <iostream>
#include <fstream>
#include <sstream>
#include <queue>
#include <stdio.h>
#include <string.h>
#include <unordered_map>
using namespace std;

struct actor_cost{
  string actor;
  int cost;
};

struct prev_actor_movie{
  string prev_actor;
  string prev_movie;
  string prev_year;
};
class CustomCompare
{
public:
    bool operator()(actor_cost& lhs, actor_cost& rhs)
    {
        return lhs.cost > rhs.cost;
        //if(lhs.cost!=rhs.cost)
	      //return lhs.actor < rhs.actor;
    }
};

void print_path(string& ans,const string &actor1,string end,unordered_map<string,prev_actor_movie >& prev){
    if(end!=actor1){
      print_path(ans,actor1,prev[end].prev_actor,prev);
    }else return;
    string cur="("+prev[end].prev_actor+")--["+prev[end].prev_movie+"#@"+prev[end].prev_year+"]-->";
    ans.append(cur);
}

int main(int argc, char *argv[]) {
  // TODO: Implement code for "Part 1: Path Finder"
  unordered_map<string,vector<string> > actortomovie;
  unordered_map<string,vector<string> > movietoactor;
  unordered_map<string,bool> allactor;
  ifstream inFile;
  string input_path=argv[1];
  //input_path="./tsv/"+input_path;
  inFile.open(input_path);
  //if(!inFile){cout << "Fail to open .tsv file in first argument!" << endl;return 0;}
  string oneline="",actor="",movie="",year="";
  bool first=true;
  bool isu=true;
  if(strcmp(argv[2],"u")==0)isu=true;
  else if(strcmp(argv[2],"w")==0)isu=false;
  //else {cout << "Please enter u or w in second argument!" << endl;return 0;}
  while(getline(inFile,oneline)){
   if(first){first=false;continue;}
    actor="";
    movie="";
    year="";
    int kind=1;
    for(int i=0;i<(int)oneline.length();i++){
      string c(1,oneline[i]);
      if(c=="\t"){
        kind++;
      }else{
        if(kind==1){
          actor.append(c);
        }else if(kind==2){
          movie.append(c);
        }else if(kind==3){
          year.append(c);
        }
      }
    }
    //numyear=atoi(year.c_str());
    string movieandyear=movie+'\t'+year;
    actortomovie[actor].push_back(movieandyear);
    movietoactor[movieandyear].push_back(actor);
    //movieyear[movie]=numyear;
    allactor[actor]=true;
    //cout << oneline << endl;
    //cout << actor << " " << movieandyear << endl;
  }
  //cout << actortomovie.size() << "\t" << allactor.size() << endl;
  inFile.close();
  ifstream inFile2;
  ofstream ofFile;
  string input_path2=argv[3];
  string output_path=argv[4];
  //input_path2="./tsv/"+input_path2;
  //output_path="./tsv/"+output_path;
  inFile2.open(input_path2);
  ofFile.open(output_path);
  if(!inFile2){cout << "Fail to open .tsv file in third argument!" << endl;return 0;}
  if(!ofFile){cout << "Fail to open .tsv file in fourth argument!" << endl;return 0;}
  string oneline2;
  bool first2=true;
  ofFile << "(actor)--[movie#@year]-->(actor)--..." << '\n';
  while(getline(inFile2,oneline2)){
   if(first2){first2=false;continue;}
    string actor1="";
    string actor2="";
    int kind=1;
    for(int i=0;i<(int)oneline2.length();i++){
      string c(1,oneline2[i]);
      if(c=="\t"){
        kind++;
      }else{
        if(kind==1){
          actor1.append(c);
        }else if(kind==2){
          actor2.append(c);
        }
      }
    }
    //cout << "actor1: " << actor1 << endl;
    //cout << "actor2: " << actor2 << endl;
    unordered_map<string,int> smallest_cost;//every actor smallest cost
    unordered_map<string,prev_actor_movie > prev;//prev actor movie year...
    unordered_map<string,bool> visit;
    unordered_map<string,bool>::iterator actor_it;
    smallest_cost[actor1]=0;
    for(actor_it=allactor.begin();actor_it!=allactor.end();actor_it++){
      if(actor_it->first!=actor1){
        smallest_cost[actor_it->first]=10000;
      }
    }
    //cout << "smallest_cost.size(): " <<smallest_cost.size() << endl;
    priority_queue<actor_cost,vector<actor_cost>,CustomCompare > p;
    actor_cost ac1;
    ac1.actor=actor1;
    ac1.cost=0;
    p.push(ac1);
    while(!p.empty()){
      actor_cost actor_tmp=p.top();p.pop();
      if(visit.find(actor_tmp.actor)==visit.end()){
        visit[actor_tmp.actor]=true;
        if(actor2==actor_tmp.actor)break;
        //if(visit.find(actor2)!=visit.end())break;
        //cout << p.size() << '\n';
        for(int i=0;i<(int)actortomovie[actor_tmp.actor].size();i++){
          int cost_tmp;
          string movie_str="";
          string year_str="";
          int kind2=1;
          for(int k=0;k<(int)actortomovie[actor_tmp.actor][i].length();k++){
            string onechar(1,actortomovie[actor_tmp.actor][i][k]);
            if(onechar=="\t"){
              kind2++;
            }else{
              if(kind2==1){
                movie_str.append(onechar);
              }else{
                year_str.append(onechar);
              }
            }
          }
          int movie_year=atoi(year_str.c_str());
          //cout << nextactor << endl;
          if(!isu)cost_tmp=1+2018-movie_year;
          else cost_tmp=1;
          //cout << movie_str << '\t' << year_str << '\n';
          for(int j=0;j<(int)movietoactor[actortomovie[actor_tmp.actor][i]].size();j++){
            const string nextactor=movietoactor[actortomovie[actor_tmp.actor][i]][j];
            if(nextactor==actor_tmp.actor)continue;
            if(smallest_cost[nextactor]>smallest_cost[actor_tmp.actor]+cost_tmp){
              smallest_cost[nextactor]=smallest_cost[actor_tmp.actor]+cost_tmp;
              prev_actor_movie pam;
              pam.prev_actor=actor_tmp.actor;
              pam.prev_movie=movie_str;
              pam.prev_year=year_str;
              prev[nextactor]=pam;
              actor_cost ac2;
              ac2.actor=nextactor;
              ac2.cost=smallest_cost[nextactor];
              p.push(ac2);
            }
          }
        }
      }
    }
    string ans;
    string end=actor2;
    print_path(ans,actor1,end,prev);
    ans.append("("+actor2+")");
    ofFile << ans << '\n';
    //cout << ans << '\n';
    //cout << smallest_cost[actor2] << endl;
  }
  inFile2.close();
  ofFile.close();
  return 0;
}
